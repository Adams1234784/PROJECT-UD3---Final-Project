package cs112.ud3;

/**
 * Custom exception class for battle-related errors.
 * This exception is thrown when invalid battle operations occur,
 * such as attacking with zero health or performing actions on defeated characters.
 */
public class BattleException extends Exception {
    
    /**
     * Constructs a new BattleException with the specified detail message.
     * 
     * @param message the detail message explaining the error
     */
    public BattleException(String message) {
        super(message);
    }
}

