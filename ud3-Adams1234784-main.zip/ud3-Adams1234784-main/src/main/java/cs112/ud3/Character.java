package cs112.ud3;

/**
 * Abstract base class representing a character in the battle game.
 * This class demonstrates inheritance and polymorphism.
 */
public abstract class Character {
    protected String name;
    protected int health;
    protected int maxHealth;
    protected int attack;
    protected int defense;
    
    /**
     * Constructs a new Character with specified attributes.
     * 
     * @param name the character's name
     * @param maxHealth the maximum health points
     * @param attack the attack power
     * @param defense the defense power
     */
    public Character(String name, int maxHealth, int attack, int defense) {
        this.name = name;
        this.maxHealth = maxHealth;
        this.health = maxHealth;
        this.attack = attack;
        this.defense = defense;
    }
    
    /**
     * Attacks another character.
     * 
     * @param target the character to attack
     * @return the damage dealt
     * @throws BattleException if the attack is invalid
     */
    public abstract int attack(Character target) throws BattleException;
    
    /**
     * Takes damage from an attack.
     * 
     * @param damage the amount of damage to take
     * @return the actual damage taken after defense
     */
    public int takeDamage(int damage) {
        int actualDamage = Math.max(1, damage - defense);
        health = Math.max(0, health - actualDamage);
        return actualDamage;
    }
    
    /**
     * Checks if the character is defeated.
     * 
     * @return true if health is 0 or less
     */
    public boolean isDefeated() {
        return health <= 0;
    }
    
    /**
     * Heals the character by a specified amount.
     * 
     * @param amount the amount to heal
     */
    public void heal(int amount) {
        health = Math.min(maxHealth, health + amount);
    }
    
    // Getters
    public String getName() {
        return name;
    }
    
    public int getHealth() {
        return health;
    }
    
    public int getMaxHealth() {
        return maxHealth;
    }
    
    public int getAttack() {
        return attack;
    }
    
    public int getDefense() {
        return defense;
    }
    
    /**
     * Gets the health percentage for display purposes.
     * 
     * @return health percentage (0-100)
     */
    public double getHealthPercentage() {
        return (double) health / maxHealth * 100;
    }
}

