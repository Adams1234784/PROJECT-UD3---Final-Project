package cs112.ud3;

/**
 * Represents a player character in the battle game.
 * Extends Character and implements player-specific attack logic.
 */
public class Player extends Character {
    
    /**
     * Constructs a new Player with default attributes.
     * 
     * @param name the player's name
     */
    public Player(String name) {
        super(name, 100, 25, 5);
    }
    
    /**
     * Constructs a new Player with custom attributes.
     * 
     * @param name the player's name
     * @param maxHealth maximum health points
     * @param attack attack power
     * @param defense defense power
     */
    public Player(String name, int maxHealth, int attack, int defense) {
        super(name, maxHealth, attack, defense);
    }
    
    @Override
    public int attack(Character target) throws BattleException {
        if (isDefeated()) {
            throw new BattleException(name + " cannot attack while defeated!");
        }
        
        if (target == null) {
            throw new BattleException("Cannot attack a null target!");
        }
        
        if (target.isDefeated()) {
            throw new BattleException("Cannot attack a defeated enemy!");
        }
        
        // Player attacks deal base attack damage with some variation
        int damage = attack + (int)(Math.random() * 10);
        target.takeDamage(damage);
        return damage;
    }
    
    /**
     * Performs a special attack that deals more damage.
     * 
     * @param target the character to attack
     * @return the damage dealt
     * @throws BattleException if the attack is invalid
     */
    public int specialAttack(Character target) throws BattleException {
        if (isDefeated()) {
            throw new BattleException(name + " cannot perform special attack while defeated!");
        }
        
        if (target == null || target.isDefeated()) {
            throw new BattleException("Invalid target for special attack!");
        }
        
        // Special attack deals 1.5x damage
        int damage = (int)(attack * 1.5) + (int)(Math.random() * 15);
        target.takeDamage(damage);
        return damage;
    }
}

