package cs112.ud3;

/**
 * Represents a monster enemy in the battle game.
 * Extends Character and implements monster-specific attack logic.
 */
public class Monster extends Character {
    
    /**
     * Constructs a new Monster with default attributes.
     * 
     * @param name the monster's name
     */
    public Monster(String name) {
        super(name, 80, 20, 3);
    }
    
    /**
     * Constructs a new Monster with custom attributes.
     * 
     * @param name the monster's name
     * @param maxHealth maximum health points
     * @param attack attack power
     * @param defense defense power
     */
    public Monster(String name, int maxHealth, int attack, int defense) {
        super(name, maxHealth, attack, defense);
    }
    
    @Override
    public int attack(Character target) throws BattleException {
        if (isDefeated()) {
            throw new BattleException(name + " cannot attack while defeated!");
        }
        
        if (target == null) {
            throw new BattleException("Cannot attack a null target!");
        }
        
        if (target.isDefeated()) {
            throw new BattleException("Cannot attack a defeated target!");
        }
        
        // Monster attacks deal base attack damage with variation
        int damage = attack + (int)(Math.random() * 8);
        target.takeDamage(damage);
        return damage;
    }
}

