package cs112.ud3;

import java.util.ArrayList;
import java.util.List;

/**
 * Manages the battle system and game state.
 * This class demonstrates encapsulation and composition.
 */
public class BattleSystem {
    private Player player;
    private List<Monster> monsters;
    private Monster currentMonster;
    private int currentMonsterIndex;
    private int round;
    private String battleLog;
    
    /**
     * Constructs a new BattleSystem with a player and list of monsters.
     * 
     * @param player the player character
     * @param monsterNames list of monster names to create
     */
    public BattleSystem(Player player, List<String> monsterNames) {
        this.player = player;
        this.monsters = new ArrayList<>();
        this.round = 1;
        this.battleLog = "";
        
        // Create monsters with varying difficulty
        for (int i = 0; i < monsterNames.size(); i++) {
            String name = monsterNames.get(i);
            // Each monster is slightly stronger than the last
            int health = 70 + (i * 10);
            int attack = 18 + (i * 2);
            int defense = 2 + i;
            monsters.add(new Monster(name, health, attack, defense));
        }
        
        if (!monsters.isEmpty()) {
            currentMonsterIndex = 0;
            currentMonster = monsters.get(0);
        }
    }
    
    /**
     * Performs a player attack on the current monster.
     * 
     * @return battle message
     * @throws BattleException if the attack is invalid
     */
    public String playerAttack() throws BattleException {
        if (isBattleOver()) {
            throw new BattleException("Battle is already over!");
        }
        
        int damage = player.attack(currentMonster);
        String message = player.getName() + " attacks " + currentMonster.getName() + 
                        " for " + damage + " damage!";
        addToLog(message);
        
        if (currentMonster.isDefeated()) {
            message += "\n" + currentMonster.getName() + " is defeated!";
            addToLog(currentMonster.getName() + " is defeated!");
            nextMonster();
        }
        
        return message;
    }
    
    /**
     * Performs a player special attack on the current monster.
     * 
     * @return battle message
     * @throws BattleException if the attack is invalid
     */
    public String playerSpecialAttack() throws BattleException {
        if (isBattleOver()) {
            throw new BattleException("Battle is already over!");
        }
        
        int damage = player.specialAttack(currentMonster);
        String message = player.getName() + " performs a SPECIAL ATTACK on " + 
                        currentMonster.getName() + " for " + damage + " damage!";
        addToLog(message);
        
        if (currentMonster.isDefeated()) {
            message += "\n" + currentMonster.getName() + " is defeated!";
            addToLog(currentMonster.getName() + " is defeated!");
            nextMonster();
        }
        
        return message;
    }
    
    /**
     * Performs a monster attack on the player.
     * 
     * @return battle message
     * @throws BattleException if the attack is invalid
     */
    public String monsterAttack() throws BattleException {
        if (isBattleOver()) {
            throw new BattleException("Battle is already over!");
        }
        
        int damage = currentMonster.attack(player);
        String message = currentMonster.getName() + " attacks " + player.getName() + 
                        " for " + damage + " damage!";
        addToLog(message);
        
        return message;
    }
    
    /**
     * Player uses a healing potion.
     * 
     * @return battle message
     * @throws BattleException if healing is invalid
     */
    public String playerHeal() throws BattleException {
        if (isBattleOver()) {
            throw new BattleException("Battle is already over!");
        }
        
        if (player.isDefeated()) {
            throw new BattleException("Cannot heal while defeated!");
        }
        
        int healAmount = 30;
        int oldHealth = player.getHealth();
        player.heal(healAmount);
        int actualHeal = player.getHealth() - oldHealth;
        
        String message = player.getName() + " heals for " + actualHeal + " HP!";
        addToLog(message);
        return message;
    }
    
    /**
     * Advances to the next monster.
     */
    private void nextMonster() {
        currentMonsterIndex++;
        if (currentMonsterIndex < monsters.size()) {
            currentMonster = monsters.get(currentMonsterIndex);
            round++;
            addToLog("Round " + round + " begins! A new " + currentMonster.getName() + " appears!");
        }
    }
    
    /**
     * Checks if the battle is over.
     * 
     * @return true if player is defeated or all monsters are defeated
     */
    public boolean isBattleOver() {
        return player.isDefeated() || (currentMonster == null || 
               (currentMonsterIndex >= monsters.size() && currentMonster.isDefeated()));
    }
    
    /**
     * Checks if the player won.
     * 
     * @return true if all monsters are defeated and player is alive
     */
    public boolean playerWon() {
        return !player.isDefeated() && 
               (currentMonsterIndex >= monsters.size() || 
                (currentMonster != null && currentMonster.isDefeated() && 
                 currentMonsterIndex >= monsters.size() - 1));
    }
    
    /**
     * Adds a message to the battle log.
     * 
     * @param message the message to add
     */
    private void addToLog(String message) {
        battleLog += message + "\n";
    }
    
    // Getters
    public Player getPlayer() {
        return player;
    }
    
    public Monster getCurrentMonster() {
        return currentMonster;
    }
    
    public int getRound() {
        return round;
    }
    
    public String getBattleLog() {
        return battleLog;
    }
    
    public void clearBattleLog() {
        battleLog = "";
    }
}

