package cs112.ud3;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;

/**
 * Controller for the battle game GUI.
 * Manages user interactions and updates the display.
 */
public class BattleController {
    @FXML
    private TextField playerNameField;
    
    @FXML
    private Button startButton;
    
    @FXML
    private Label playerNameLabel;
    
    @FXML
    private Label playerHealthLabel;
    
    @FXML
    private ProgressBar playerHealthBar;
    
    @FXML
    private Label monsterNameLabel;
    
    @FXML
    private Label monsterHealthLabel;
    
    @FXML
    private ProgressBar monsterHealthBar;
    
    @FXML
    private Button attackButton;
    
    @FXML
    private Button specialAttackButton;
    
    @FXML
    private Button healButton;
    
    @FXML
    private TextArea battleLogArea;
    
    @FXML
    private Label roundLabel;
    
    @FXML
    private Label statusLabel;
    
    @FXML
    private VBox gameArea;
    
    @FXML
    private VBox startArea;
    
    private BattleSystem battleSystem;
    private boolean gameStarted = false;
    
    /**
     * Initializes the controller.
     */
    @FXML
    public void initialize() {
        // Hide game area initially
        gameArea.setVisible(false);
        gameArea.setManaged(false);
        
        // Show start area
        startArea.setVisible(true);
        startArea.setManaged(true);
        
        // Set initial button states
        attackButton.setDisable(true);
        specialAttackButton.setDisable(true);
        healButton.setDisable(true);
    }
    
    /**
     * Starts a new battle game.
     */
    @FXML
    protected void onStartButtonClick() {
        String playerName = playerNameField.getText().trim();
        if (playerName.isEmpty()) {
            playerName = "Hero";
        }
        
        // Create player and monsters
        Player player = new Player(playerName);
        java.util.List<String> monsterNames = java.util.Arrays.asList(
            "Goblin", "Orc", "Troll", "Dragon"
        );
        
        battleSystem = new BattleSystem(player, monsterNames);
        gameStarted = true;
        
        // Show game area, hide start area
        startArea.setVisible(false);
        startArea.setManaged(false);
        gameArea.setVisible(true);
        gameArea.setManaged(true);
        
        // Enable battle buttons
        attackButton.setDisable(false);
        specialAttackButton.setDisable(false);
        healButton.setDisable(false);
        
        // Update display
        updateDisplay();
        
        // Add welcome message
        battleLogArea.appendText("=== BATTLE BEGINS ===\n");
        battleLogArea.appendText("Round " + battleSystem.getRound() + ": " + 
                                battleSystem.getCurrentMonster().getName() + " appears!\n");
        battleLogArea.appendText("Choose your action!\n\n");
    }
    
    /**
     * Performs a normal attack.
     */
    @FXML
    protected void onAttackButtonClick() {
        if (!gameStarted || battleSystem.isBattleOver()) {
            return;
        }
        
        try {
            // Player attacks
            String message = battleSystem.playerAttack();
            battleLogArea.appendText(message + "\n");
            
            // Check if battle is over
            if (battleSystem.isBattleOver()) {
                endBattle();
                return;
            }
            
            // Monster attacks back
            String monsterMessage = battleSystem.monsterAttack();
            battleLogArea.appendText(monsterMessage + "\n");
            
            // Check if battle is over after monster attack
            if (battleSystem.isBattleOver()) {
                endBattle();
                return;
            }
            
            updateDisplay();
            
        } catch (BattleException e) {
            battleLogArea.appendText("ERROR: " + e.getMessage() + "\n");
        }
    }
    
    /**
     * Performs a special attack.
     */
    @FXML
    protected void onSpecialAttackButtonClick() {
        if (!gameStarted || battleSystem.isBattleOver()) {
            return;
        }
        
        try {
            // Player special attack
            String message = battleSystem.playerSpecialAttack();
            battleLogArea.appendText(message + "\n");
            
            // Check if battle is over
            if (battleSystem.isBattleOver()) {
                endBattle();
                return;
            }
            
            // Monster attacks back
            String monsterMessage = battleSystem.monsterAttack();
            battleLogArea.appendText(monsterMessage + "\n");
            
            // Check if battle is over after monster attack
            if (battleSystem.isBattleOver()) {
                endBattle();
                return;
            }
            
            updateDisplay();
            
        } catch (BattleException e) {
            battleLogArea.appendText("ERROR: " + e.getMessage() + "\n");
        }
    }
    
    /**
     * Heals the player.
     */
    @FXML
    protected void onHealButtonClick() {
        if (!gameStarted || battleSystem.isBattleOver()) {
            return;
        }
        
        try {
            // Player heals
            String message = battleSystem.playerHeal();
            battleLogArea.appendText(message + "\n");
            
            // Monster attacks back
            String monsterMessage = battleSystem.monsterAttack();
            battleLogArea.appendText(monsterMessage + "\n");
            
            // Check if battle is over after monster attack
            if (battleSystem.isBattleOver()) {
                endBattle();
                return;
            }
            
            updateDisplay();
            
        } catch (BattleException e) {
            battleLogArea.appendText("ERROR: " + e.getMessage() + "\n");
        }
    }
    
    /**
     * Updates the display with current game state.
     */
    private void updateDisplay() {
        if (battleSystem == null) {
            return;
        }
        
        Player player = battleSystem.getPlayer();
        Monster monster = battleSystem.getCurrentMonster();
        
        // Update player info
        playerNameLabel.setText(player.getName());
        playerHealthLabel.setText(player.getHealth() + " / " + player.getMaxHealth() + " HP");
        playerHealthBar.setProgress(player.getHealthPercentage() / 100.0);
        
        // Update monster info
        if (monster != null) {
            monsterNameLabel.setText(monster.getName());
            monsterHealthLabel.setText(monster.getHealth() + " / " + monster.getMaxHealth() + " HP");
            monsterHealthBar.setProgress(monster.getHealthPercentage() / 100.0);
        }
        
        // Update round
        roundLabel.setText("Round: " + battleSystem.getRound());
        
        // Update status
        if (battleSystem.isBattleOver()) {
            if (battleSystem.playerWon()) {
                statusLabel.setText("VICTORY!");
                statusLabel.setStyle("-fx-text-fill: green; -fx-font-weight: bold;");
            } else {
                statusLabel.setText("DEFEAT!");
                statusLabel.setStyle("-fx-text-fill: red; -fx-font-weight: bold;");
            }
        } else {
            statusLabel.setText("Battle in Progress");
            statusLabel.setStyle("-fx-text-fill: black;");
        }
        
        // Disable buttons if battle is over
        if (battleSystem.isBattleOver()) {
            attackButton.setDisable(true);
            specialAttackButton.setDisable(true);
            healButton.setDisable(true);
        }
    }
    
    /**
     * Ends the battle and displays final message.
     */
    private void endBattle() {
        updateDisplay();
        
        if (battleSystem.playerWon()) {
            battleLogArea.appendText("\n=== VICTORY! ===\n");
            battleLogArea.appendText("You have defeated all monsters!\n");
        } else {
            battleLogArea.appendText("\n=== DEFEAT ===\n");
            battleLogArea.appendText("You have been defeated...\n");
        }
        
        battleLogArea.appendText("\nClick 'Start New Battle' to play again.\n");
    }
}

